package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.cg.fms.DBUtil.DBUtil;
import com.cg.fms.bean.TrainingBean;
import com.cg.fms.exception.FeedbackException;


public class FmsDaoImpl implements IFmsDao {
	Connection conn = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	@Override
	public int insertDetails(TrainingBean training) throws FeedbackException {
		String insertQry = "INSERT INTO Training_Master(training_code,course_code,faculty_code,start_date,end_date)  VALUES(?, ?, ?, ?, ?)";
		 training.setTrainingCode(generateTrainingCode());
		 int dataAdded;
		
		try
		{
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(insertQry);
			pst.setLong(1, training.getTrainingCode());
			pst.setLong(2, training.getCourseCode());
			pst.setLong(3, training.getFacultyCode());
			pst.setDate(4, Date.valueOf(training.getStartDate()));
			pst.setDate(5, Date.valueOf(training.getEndDate()));
		
			dataAdded =pst.executeUpdate();
			System.out.println("data: "+dataAdded);
		} 
		catch (Exception e) 
		{
			throw new FeedbackException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				conn.close();
			} 
			catch (SQLException e) 
			{
				
				throw new FeedbackException(e.getMessage());
			}
		}
		return dataAdded;
	
	}

	private long generateTrainingCode()  throws FeedbackException 
	{
			long tcode;
			String qry = "SELECT seq_training_code.NEXTVAL FROM DUAL";
	        conn=DBUtil.getConnection();
			try
			{
			Statement st=conn.createStatement();
			ResultSet rst=st.executeQuery(qry);
			rst.next();
			tcode=rst.getLong(1);
		    }
			catch(SQLException e)
			{
			throw new FeedbackException("Problem in generating purchaseid:"+e.getMessage());
		    }
			finally
			{
				try 
				{
					rs.close();
					st.close();
					conn.close();  
				} 
				catch (SQLException e) 
				{
					throw new FeedbackException(e.getMessage());
				}
			}
			return tcode;
	}
}
