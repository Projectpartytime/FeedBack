package com.cg.fms.service;

import com.cg.fms.bean.TrainingBean;
import com.cg.fms.exception.FeedbackException;


public interface IFmsService 
{
	
	public int insertDetails(TrainingBean training) throws FeedbackException;

}
