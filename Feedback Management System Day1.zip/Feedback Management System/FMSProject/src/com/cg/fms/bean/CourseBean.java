package com.cg.fms.bean;
/*Name                                      Null?    Type
----------------------------------------- -------- -------------------

COURSE_ID                                 NOT NULL NUMBER(5)
COURSE_NAME                                        VARCHAR2(50)
NO_OF_DAYS                                         NUMBER(5)
*/
public class CourseBean 
{
	private long courseId;
	private String courseName;
	private long noOfDays;
	
	public CourseBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CourseBean(long courseId, String courseName, long noOfDays) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.noOfDays = noOfDays;
	}
	public long getCourseId() {
		return courseId;
	}
	public void setCourseId(long courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public long getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(long noOfDays) {
		this.noOfDays = noOfDays;
	}
	@Override
	public String toString() {
		return "CourseBean [courseId=" + courseId + ", courseName="
				+ courseName + ", noOfDays=" + noOfDays + "]";
	}
	

}
