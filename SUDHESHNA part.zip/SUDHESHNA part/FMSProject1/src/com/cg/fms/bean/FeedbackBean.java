package com.cg.fms.bean;
/* Name                                      Null?    Type
 ----------------------------------------- -------- -------------------
 TRAINING_CODE                                      NUMBER(5)
 PARTICIPANT_ID                                     NUMBER(5)
 FB_PRS_COMM                                        NUMBER(1)
 FB_CLRFY_DBTS                                      NUMBER(1)
 FB_TM                                              NUMBER(1)
 FB_HAND_OUT                                        NUMBER(1)
 FB_HW_SW_NTWRK                                     NUMBER(1)
 COMMENTS                                           VARCHAR2(200)
 SUGGESTIONS                                        VARCHAR2(200)
 */
public class FeedbackBean 
{
	private long trainingCode;
	private long participantId;
	private int presentComm;
	private int clarifyDoubt;
	private int timeManage;
	private int handOut;
	private int hardSoftNet;
	private String comments;
	private String suggestions;
	
	public FeedbackBean() 
	{
		super();
	}
	
	public FeedbackBean(long trainingCode, long participantId, int presentComm,
			int clarifyDoubt, int timeManage, int handOut, int hardSoftNet,
			String comments, String suggestions) 
	{
		super();
		this.trainingCode = trainingCode;
		this.participantId = participantId;
		this.presentComm = presentComm;
		this.clarifyDoubt = clarifyDoubt;
		this.timeManage = timeManage;
		this.handOut = handOut;
		this.hardSoftNet = hardSoftNet;
		this.comments = comments;
		this.suggestions = suggestions;
	}
	
	public long getTrainingCode()
	{
		return trainingCode;
	}
	public void setTrainingCode(long trainingCode) 
	{
		this.trainingCode = trainingCode;
	}
	public long getParticipantId()
	{
		return participantId;
	}
	public void setParticipantId(long participantId)
	{
		this.participantId = participantId;
	}
	public int getPresentComm() 
	{
		return presentComm;
	}
	public void setPresentComm(int presentComm)
	{
		this.presentComm = presentComm;
	}
	public int getClarifyDoubt()
	{
		return clarifyDoubt;
	}
	public void setClarifyDoubt(int clarifyDoubt)
	{
		this.clarifyDoubt = clarifyDoubt;
	}
	public int getTimeManage()
	{
		return timeManage;
	}
	public void setTimeManage(int timeManage)
	{
		this.timeManage = timeManage;
	}
	public int getHandOut() 
	{
		return handOut;
	}
	public void setHandOut(int handOut)
	{
		this.handOut = handOut;
	}
	public int getHardSoftNet()
	{
		return hardSoftNet;
	}
	public void setHardSoftNet(int hardSoftNet) 
	{
		this.hardSoftNet = hardSoftNet;
	}
	public String getComments() 
	{
		return comments;
	}
	public void setComments(String comments)
	{
		this.comments = comments;
	}
	public String getSuggestions() 
	{
		return suggestions;
	}
	public void setSuggestions(String suggestions) 
	{
		this.suggestions = suggestions;
	}

	@Override
	public String toString() 
	{
		return "FeedbackBean [trainingCode=" + trainingCode
				+ ", participantId=" + participantId + ", presentComm="
				+ presentComm + ", clarifyDoubt=" + clarifyDoubt
				+ ", timeManage=" + timeManage + ", handOut=" + handOut
				+ ", hardSoftNet=" + hardSoftNet + ", comments=" + comments
				+ ", suggestions=" + suggestions + "]";
	}
	
	

}
