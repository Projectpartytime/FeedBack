package com.cg.fms.ui;

import java.util.Scanner;

public class FmsController 
{
	static Scanner sc=new Scanner(System.in);

	public static void main(String[] args)
	{
		System.out.println("\n Enter your role");
		System.out.println("\n 1.Training  Admin "
				+"\n 2.Co-coordinator "
				+"\n 3.Participant"
				+"\n 4.Exit");
		int role=sc.nextInt();

		switch(role)
		{
		case 1:
		{
			break;
		}
		case 2:
		{
			break;
		}
		case 3:
		{
			System.out.println("Feedback Form "
					+ "\n Rate the question according to following criteria"
					+ "\n 5-Excellent: Ideal way of doing it"
					+ "\n 4-Good: No pain areas or concern but could have been better"
					+ "\n 3-Average: There are concerns but not significant"
					+ "\n 2-Below Average: Needs improvement and is salvageable"
					+ "\n 1-Poor: This way of doing things must change");

			System.out.println("Presentation and communication skills of faculty");
			int presentComm = sc.nextInt();

			System.out.println("Ability to clarify doubts and explain difficult points");
			int clarifyDoubt = sc.nextInt();

			System.out.println("Time management in completing the contents");
			int timeManage = sc.nextInt();

			System.out.println("Handout provided(Student Guide)");
			int handOut = sc.nextInt();

			System.out.println("Hardware, software and network availability");
			int hardSoftNet = sc.nextInt();

			System.out.println("Please give comments");
			sc.nextLine();
			String comments = sc.nextLine();

			System.out.println("Please give some suggestions?");
			sc.nextLine();
			String suggestions = sc.nextLine(); 
			
			
			break;
		}
		default:
			System.exit(0);
			break;

		}


	}

}
