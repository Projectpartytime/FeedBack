package com.cg.fms.service;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.dao.*;
import com.cg.fms.exception.FeedbackException;

public class FmsServiceImpl implements IFmsService
{
	IFmsDao fmsdao=null;
	public FmsServiceImpl() 
	{
		super();
		// TODO Auto-generated constructor stub
		fmsdao=new FmsDaoImpl();
	}

	@Override
	public long getEmployeeId(EmployeeBean ebean)throws FeedbackException
	{

		return fmsdao.getEmployeeId(ebean);
	}

	@Override
	public long insertCourseDetails(CourseBean cbean) throws FeedbackException {
		// TODO Auto-generated method stub
		return fmsdao.insertCourseDetails(cbean);
	}

	@Override
	public FeedbackBean getFeedbackByTrainingCode(long trainingCode)
			throws FeedbackException {
		// TODO Auto-generated method stub
		return fmsdao.getFeedbackByTrainingCode(trainingCode); 
	}

	@Override
	public FeedbackBean getFeedbackByParticipantId(long participantId)
			throws FeedbackException {
		// TODO Auto-generated method stub
		return fmsdao.getFeedbackByParticipantId(participantId);
	}

}
