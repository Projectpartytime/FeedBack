package com.cg.fms.service;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.exception.FeedbackException;

public interface IFmsService 
{
	public long getEmployeeId(EmployeeBean ebean)throws FeedbackException;
	public long insertCourseDetails(CourseBean cbean)throws FeedbackException;
	public FeedbackBean getFeedbackByTrainingCode(long trainingCode)throws FeedbackException;
	public FeedbackBean getFeedbackByParticipantId(long participantId)throws FeedbackException;
}
