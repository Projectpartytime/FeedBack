package com.cg.fms.dao;

public interface QueryMapper
{	
	String Faculty_Skill_Maintenance="SELECT employee_id FROM EMPLOYEE_MASTER WHERE skillset=?";
	String Course_Maintenance="INSERT INTO COURSE_MASTER(Course_ID,Course_Name,no_of_days)VALUES(?,?,?)";
	String View_Feedback_Report_By_TrainingCode="SELECT participant_id,fb_prs_comm,fb_clrfy_dbts,fb_tm,fb_hand_out,fb_hw_sw_ntwrk,comments,suggestions FROM feedback_master WHERE training_code=?";
	String View_Feedback_Report_By_ParticipantId="SELECT fb_prs_comm,fb_clrfy_dbts,fb_tm,fb_hand_out,fb_hw_sw_ntwrk,comments,suggestions FROM feedback_master WHERE participant_id=?";	
	String selectsequence="SELECT course_seq.NEXTVAL FROM DUAL";
}
