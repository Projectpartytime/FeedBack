package com.cg.fms.dao;

import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.exception.FeedbackException;

public interface IFmsDao 
{

	int insertFeedback(FeedbackBean feedback) throws FeedbackException;
}
