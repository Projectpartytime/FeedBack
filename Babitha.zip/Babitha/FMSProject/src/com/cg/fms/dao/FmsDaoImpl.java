package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.fms.DBUtil.DBUtil;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.exception.FeedbackException;


public class FmsDaoImpl implements IFmsDao {

	Connection conn;
	
	@Override
	public int insertFeedback(FeedbackBean feedback) throws FeedbackException {
		conn = DBUtil.getConnection();
		int dataInserted;
		try 
		{
			PreparedStatement pst = conn.prepareStatement(QueryMapper.INSERT_PARTICIPANT_FB);
			pst.setLong(1, feedback.getTrainingCode());
			pst.setLong(2, feedback.getParticipantId());
			pst.setInt(3, feedback.getPresentComm());
			pst.setInt(4, feedback.getClarifyDoubt());
			pst.setInt(5, feedback.getTimeManage());
			pst.setInt(6, feedback.getHandOut());
			pst.setInt(7, feedback.getHardSoftNet());
			pst.setString(8, feedback.getComments());
			pst.setString(9, feedback.getSuggestions());
			
			dataInserted = pst.executeUpdate();
		} 
		catch (SQLException e) 
		{
			throw new FeedbackException("Problem in inserting feedback details: "+e.getMessage());
		}
		
		return dataInserted;
	}

}
