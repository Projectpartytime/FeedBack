package com.cg.fms.dao;

public interface QueryMapper {
	
	String INSERT_PARTICIPANT_FB = "INSERT INTO feedback_master(training_code,participant_id,fb_prs_comm, fb_clrfy_dbts, fb_tm, fb_hand_out, fb_hw_sw_ntwrk, comments, suggestions) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
}
