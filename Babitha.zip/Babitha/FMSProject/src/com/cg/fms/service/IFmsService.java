package com.cg.fms.service;

import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.exception.FeedbackException;

public interface IFmsService {

	int insertFeedback(FeedbackBean feedback) throws FeedbackException;

}
