package com.cg.fms.service;

import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.dao.FmsDaoImpl;
import com.cg.fms.dao.IFmsDao;
import com.cg.fms.exception.FeedbackException;

public class FmsServiceImpl implements IFmsService {

	IFmsDao fmsDao = new FmsDaoImpl();
	@Override
	public int insertFeedback(FeedbackBean feedback) throws FeedbackException {
		
		return fmsDao.insertFeedback(feedback);
	}

}
