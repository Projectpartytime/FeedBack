package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.util.DBUtil;


public class FmsDaoImpl implements IFmsDao {

	Connection conn;
	PreparedStatement pst;
	ResultSet rs;
	Statement st;
	
	@Override
	public int insertFeedback(FeedbackBean feedback) throws FeedbackException {
		conn = DBUtil.getConnection();
		int dataInserted;
		try 
		{
			
			pst = conn.prepareStatement(QueryMapper.INSERT_PARTICIPANT_FB);
			pst.setLong(1, feedback.getTrainingCode());
			pst.setLong(2, feedback.getParticipantId());
			pst.setInt(3, feedback.getPresentComm());
			pst.setInt(4, feedback.getClarifyDoubt());
			pst.setInt(5, feedback.getTimeManage());
			pst.setInt(6, feedback.getHandOut());
			pst.setInt(7, feedback.getHardSoftNet());
			pst.setString(8, feedback.getComments());
			pst.setString(9, feedback.getSuggestions());
			
			dataInserted = pst.executeUpdate();
		} 
		catch (Exception e) 
		{
			throw new FeedbackException("Problem in inserting feedback details: "+e.getMessage());
		}
		
		return dataInserted;
	}

	@Override
	public long getEmployeeId(EmployeeBean ebean) throws FeedbackException {
		try 
		{
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.Faculty_Skill_Maintenance);
			pst.setString(1,ebean.getSkillSet());
			rs=pst.executeQuery();
			
			if(rs.next())
			{
			ebean=new EmployeeBean();
			ebean.setEmployeeId(rs.getLong("employee_id"));
			ebean.setEmployeeName(rs.getString("employee_name"));
			ebean.setRole(rs.getString("role"));
			ebean.setSkillSet(rs.getString("skillset"));

			}
		}
		catch (Exception e)
		{
			throw new FeedbackException("Problem in fetching EmployeeId"+e.getMessage());

		}
		return ebean.getEmployeeId();
	}

	@Override
	public long insertCourseDetails(CourseBean cbean) throws FeedbackException {
		cbean.setCourseId(generateCourseId());
		try 
		{
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.Course_Maintenance);
			pst.setLong(1,cbean.getCourseId());
			pst.setString(2,cbean.getCourseName());
			pst.setLong(3,cbean.getNoOfDays());
			pst.executeUpdate();
		}
		catch (Exception e)
		{
			throw new FeedbackException("Problem in inserting CourseDetails"+e.getMessage());

		}
		return cbean.getCourseId();
	}

	@Override
	public FeedbackBean getFeedbackByTrainingCode(long trainingCode)
			throws FeedbackException {
		FeedbackBean fbean=null;	
		try 
		{
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.View_Feedback_Report_By_ParticipantId);
			pst.setLong(1, trainingCode);
			rs=pst.executeQuery();
			if(rs.next())
			{
				fbean=new FeedbackBean();
				fbean.setTrainingCode(rs.getLong("training_code"));
				fbean.setParticipantId(rs.getLong("participant_id"));
				fbean.setPresentComm(rs.getInt("fb_prs_comm"));
				fbean.setClarifyDoubt(rs.getInt("fb_clrfy_dbts"));
				fbean.setTimeManage(rs.getInt("fb_tm"));
				fbean.setHandOut(rs.getInt("fb_hand_out"));		
				fbean.setHardSoftNet(rs.getInt("fb_hw_sw_ntwrk"));
				fbean.setComments(rs.getString("comments"));
				fbean.setSuggestions(rs.getString("suggestions"));
				
			}
			else
			{
				throw new FeedbackException("Feedback not filled");
			}

		}
		catch (Exception e)
		{

			throw new FeedbackException("Problem in fetching Feedback based on TrainingCode"+e.getMessage());

		} 
		return fbean;
	}

	@Override
	public FeedbackBean getFeedbackByParticipantId(long participantId)
			throws FeedbackException {
		FeedbackBean fbean=null;	
		try 
		{
			conn=DBUtil.getConnection();
			pst=conn.prepareStatement(QueryMapper.View_Feedback_Report_By_ParticipantId);
			pst.setLong(1, participantId);
			rs=pst.executeQuery();;
			if(rs.next())
			{
				fbean=new FeedbackBean();
				fbean.setTrainingCode(rs.getLong("training_code"));
				fbean.setParticipantId(rs.getLong("participant_id"));
				fbean.setPresentComm(rs.getInt("fb_prs_comm"));
				fbean.setClarifyDoubt(rs.getInt("fb_clrfy_dbts"));
				fbean.setTimeManage(rs.getInt("fb_tm"));
				fbean.setHandOut(rs.getInt("fb_hand_out"));		
				fbean.setHardSoftNet(rs.getInt("fb_hw_sw_ntwrk"));
				fbean.setComments(rs.getString("comments"));
				fbean.setSuggestions(rs.getString("suggestions"));
				
			}
			else
			{
				throw new FeedbackException("Feedback not filled By Participant");
			}

		}
		catch (Exception e)
		{

			throw new FeedbackException("Problem in fetching Feedback from Participant"+e.getMessage());

		} 
		return fbean;
	}
	
	private long generateCourseId() throws FeedbackException 
	{
		long courseId=0;
		try 
		{
			conn=DBUtil.getConnection();
			st=conn.createStatement();
			rs=st.executeQuery(QueryMapper.selectsequence);
			rs.next();
			courseId=rs.getLong(1);

		}
		catch (Exception e) 
		{
			throw new FeedbackException("Problem in generating sequence"+e.getMessage());
		}
		return courseId;
	}

}
