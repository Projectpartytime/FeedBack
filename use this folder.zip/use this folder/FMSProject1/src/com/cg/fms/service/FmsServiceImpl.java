package com.cg.fms.service;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.EmployeeBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.dao.FmsDaoImpl;
import com.cg.fms.dao.IFmsDao;
import com.cg.fms.exception.FeedbackException;

public class FmsServiceImpl implements IFmsService {

	IFmsDao fmsDao = new FmsDaoImpl();
	@Override
	public int insertFeedback(FeedbackBean feedback) throws FeedbackException {
		
		return fmsDao.insertFeedback(feedback);
	}
	@Override
	public long getEmployeeId(EmployeeBean ebean) throws FeedbackException {
		// TODO Auto-generated method stub
		return fmsDao.getEmployeeId(ebean);
	}
	@Override
	public long insertCourseDetails(CourseBean cbean) throws FeedbackException {
		// TODO Auto-generated method stub
		return fmsDao.insertCourseDetails(cbean);
	}
	@Override
	public FeedbackBean getFeedbackByTrainingCode(long trainingCode)
			throws FeedbackException {
		// TODO Auto-generated method stub
		return fmsDao.getFeedbackByTrainingCode(trainingCode);
	}
	@Override
	public FeedbackBean getFeedbackByParticipantId(long participantId)
			throws FeedbackException {
		// TODO Auto-generated method stub
		return fmsDao.getFeedbackByParticipantId(participantId);
	}

}
