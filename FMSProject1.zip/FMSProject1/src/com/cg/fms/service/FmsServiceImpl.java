package com.cg.fms.service;

import com.cg.fms.bean.TrainingBean;
import com.cg.fms.dao.FmsDaoImpl;
import com.cg.fms.dao.IFmsDao;
import com.cg.fms.exception.FeedbackException;

public class FmsServiceImpl implements IFmsService {
	IFmsDao  fmdao=new FmsDaoImpl();

	@Override
	public int insertDetails(TrainingBean training) throws FeedbackException {
		
		return fmdao.insertDetails(training);
	}

}
