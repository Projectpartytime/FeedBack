package com.cg.fms.dao;

import com.cg.fms.bean.TrainingBean;
import com.cg.fms.exception.FeedbackException;


public interface IFmsDao 
{
	
	public int insertDetails(TrainingBean training) throws FeedbackException;

}
